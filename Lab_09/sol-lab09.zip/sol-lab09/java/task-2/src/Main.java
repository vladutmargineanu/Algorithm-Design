import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;

public class Main {
	static class Task {
		public static final String INPUT_FILE = "in";
		public static final String OUTPUT_FILE = "out";
		public static final int NMAX = 50005;

		int n;
		int m;
		int source;

		public class Edge {
			public int node;
			public int cost;

			Edge(int _node, int _cost) {
				node = _node;
				cost = _cost;
			}
		}

		@SuppressWarnings("unchecked")
		ArrayList<Edge> adj[] = new ArrayList[NMAX];

		private void readInput() {
			try {
				Scanner sc = new Scanner(new BufferedReader(new FileReader(
								INPUT_FILE)));
				n = sc.nextInt();
				m = sc.nextInt();
				source = sc.nextInt();

				for (int i = 1; i <= n; i++)
					adj[i] = new ArrayList<>();
				for (int i = 1; i <= m; i++) {
					int x, y, w;
					x = sc.nextInt();
					y = sc.nextInt();
					w = sc.nextInt();
					adj[x].add(new Edge(y, w));
				}
				sc.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		private void writeOutput(ArrayList<Integer> result) {
			try {
				BufferedWriter bw = new BufferedWriter(new FileWriter(
								OUTPUT_FILE));
				StringBuilder sb = new StringBuilder();
				if (result.size() == 0) {
					sb.append("Ciclu negativ!\n");
				} else {
					for (int i = 1; i <= n; i++) {
						sb.append(result.get(i)).append(' ');
					}
					sb.append('\n');
				}
				bw.write(sb.toString());
				bw.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		class BellmanEdge {
			int x, y, cost;

			public BellmanEdge(int _x, int _y, int _cost) {
				x = _x;
				y = _y;
				cost = _cost;
			}
		}

		public static int INF = 0x3f3f3f3f;

		private ArrayList<Integer> getResult() {
			// TODO: Gasiti distantele minime de la nodul source la celelalte noduri
			// folosind BellmanFord pe graful orientat cu n noduri, m arce stocat in
			// adj.
			//	d[node] = costul minim / lungimea minima a unui drum de la source la
			//	nodul node;
			//	d[source] = 0;
			//	d[node] = -1, daca nu se poate ajunge de la source la node.

			// Atentie:
			// O muchie este tinuta ca o pereche (nod adiacent, cost muchie):
			//	adj[x].get(i).node = nodul adiacent lui x,
			//	adj[x].get(i).cost = costul.

			// In cazul in care exista ciclu de cost negativ, returnati un vector gol:
			//	return new ArrayList<Integer>();
			ArrayList<Integer> d = new ArrayList<>();
			for (int i = 0; i <= n; i++)
				d.add(INF);

			// Construiesc un vector cu toate muchiile.
			ArrayList<BellmanEdge> edges = new ArrayList<>();
			for (int x = 1; x <= n; x++) {
				for (Edge e : adj[x]) {
					edges.add(new BellmanEdge(x, e.node, e.cost));
				}
			}

			// Setez sursa pe 0.
			d.set(source, 0);

			// Fac n - 1 relaxari.
			for (int i = 1; i <= n - 1; i++) {
				for (BellmanEdge e : edges) {
					// Daca este posibila updatarea distantei,
					if (d.get(e.y) > d.get(e.x) + e.cost) {
						// O updatez.
						d.set(e.y, d.get(e.x) + e.cost);
					}
				}
			}

			// Daca mai pot sa mai relaxez, inseamna ca exista ciclu de cost negativ.
			for (BellmanEdge e : edges) {
				if (d.get(e.y) > d.get(e.x) + e.cost) {
					return new ArrayList<Integer>();
				}
			}

			// Toate nodurile catre care distanta este inca INF nu pot fi atinse din
			// nodul source, deci le setam pe -1.
			for (int i = 1; i <= n; i++)
				if (d.get(i) == INF)
					d.set(i, -1);

			return d;
		}

		public void solve() {
			readInput();
			writeOutput(getResult());
		}
	}

	public static void main(String[] args) {
		new Task().solve();
	}
}
